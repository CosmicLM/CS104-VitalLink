# TODO:
# - Copy over your code from the previous medication tracker exercise
# - Change your medications variable from a list to a dictionary
#   - The keys should be the medication names and the values should be the dosage amounts
# - Add an option to update the dosage amount for a medication
