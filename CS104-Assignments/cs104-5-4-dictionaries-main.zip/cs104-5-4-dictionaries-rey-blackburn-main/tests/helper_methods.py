import subprocess
import sys
import os

def run_tracker(inputs):
    """Run medicationTracker.py with a list of inputs, return output as string."""
    # Prepare input as a single string
    input_str = "\n".join(inputs) + "\n"
    result = subprocess.run(
        [sys.executable, os.path.join(os.path.dirname(__file__), '../medicationTracker.py')],
        input=input_str.encode(),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=5
    )
    return result.stdout.decode()