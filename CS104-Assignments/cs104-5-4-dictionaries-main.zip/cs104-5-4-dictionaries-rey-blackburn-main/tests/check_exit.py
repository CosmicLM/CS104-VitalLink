from helper_methods import run_tracker
from common_setup import run_test

def exit_test():
    output = run_tracker(["5"])
    assert output, "\U0000274C medicationTracker.py did not print any output. Hint: make sure to use print()!"
    assert "Thank you" in output, (
        "\U0000274C Option 5 (Exit) did not print the exit message.\n"
        "\U0001F4A1 Hint: Print a thank you message when exiting."
    )

def test_exit():
    run_test("check_exit", "Option 5: Exit - print a thank you message and exit the program", "\U0000274C Option 5 (Exit) did not print the exit message.")