from helper_methods import run_tracker
from common_setup import run_test

def add_medication_test():
    output = run_tracker(["2", "Ibuprofen", "1", "4"])
    assert output, "\U0000274C medicationTracker.py did not print any output. Hint: make sure to use print()!"
    assert "'Ibuprofen' has been added" in output, (
        "\U0000274C Option 2 (Add medication) did not confirm addition.\n"
        "\U0001F4A1 Hint: Print \"'<ADDED_MEDICATION>' has been added\" after the user adds a medication."
    )
    assert "Ibuprofen" in output, (
        "\U0000274C Option 2 (Add medication) did not show the medication in the list.\n"
        "\U0001F4A1 Hint: After adding, viewing should list the medication."
    )

def test_add_medication():
    run_test("check_add_medication", "Option 2: Add Medication - add a medication to the dictionary", "\U0000274C Option 2 (Add medication) did not show/confirm addition.")