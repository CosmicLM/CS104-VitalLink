# *****************************************************************************
# *                                                                           *
# *   IMPORTANT: DO NOT MODIFY THIS FILE                                      *
# *                                                                           *
# *   This testing file is provided to help you check the functionality of    *
# *   your code and understand the requirements for this assignment.          *
# *                                                                           *
# *   Please review the tests carefully to understand what is expected, but   *
# *   DO NOT make any changes to this file. Modifying this file will          *
# *   interfere with the grading system, lead to incorrect results, and       *
# *   will be flagged as cheating.                                            *
# *                                                                           *
# *   Focus on writing your own code to meet the requirements outlined in the *
# *   tests.                                                                  *
# *                                                                           *
# *****************************************************************************

from central_setup.central_setup import ( check_internet_connection )
from common_setup import pre_test_setup
from check_view_medications import view_medications_test
from check_add_medication import add_medication_test
from check_update_medication import update_medication_test
from check_remove_medication import remove_medication_test
from check_exit import exit_test

def test_all():

    # Online testing
    if check_internet_connection():
        test_outputs, test_points_awarded, test_feedback,test_response_data = pre_test_setup()
        assert test_response_data['totalPointsAwarded'] == test_response_data['totalPointsPossible'], test_feedback

    # Offline testing
    else :
        view_medications_test()
        add_medication_test()
        update_medication_test()
        remove_medication_test()
        exit_test()
