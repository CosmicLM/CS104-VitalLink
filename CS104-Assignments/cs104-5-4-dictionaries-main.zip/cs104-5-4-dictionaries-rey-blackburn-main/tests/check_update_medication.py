from helper_methods import run_tracker
from common_setup import run_test

def update_medication_test():
    # Add, update, then view
    output = run_tracker(["2", "Lipitor", "20", "3", "Lipitor", "40", "1", "5"])
    assert output, "\U0000274C medicationTracker.py did not print any output. Hint: make sure to use print()!"
    assert "'Lipitor' has been updated" in output, (
        "\U0000274C Option 3 (Update dosage) did not confirm update.\n"
        "\U0001F4A1 Hint: Print \"'<MEDICATION>' has been updated\" after the user updates a dosage."
    )
    assert "Lipitor: 40mg" in output, (
        "\U0000274C Option 3 (Update dosage) did not show the updated dosage in the list.\n"
        "\U0001F4A1 Hint: After updating, viewing should list the medication with the new dosage."
    )

def test_update_medication():
    run_test("check_update_medication", "Option 3: Update Medication Dosage - change the dosage of an existing medication in the dictionary", "\U0000274C Option 3 (Update dosage) did not confirm update/show updated dosage in the list.")