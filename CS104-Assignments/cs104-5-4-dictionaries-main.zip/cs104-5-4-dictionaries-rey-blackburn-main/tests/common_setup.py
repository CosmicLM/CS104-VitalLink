# *****************************************************************************
# *                                                                           *
# *   IMPORTANT: DO NOT MODIFY THIS FILE                                      *
# *                                                                           *
# *   This testing file is provided to help you check the functionality of    *
# *   your code and understand the requirements for this assignment.          *
# *                                                                           *
# *   Please review the tests carefully to understand what is expected, but   *
# *   DO NOT make any changes to this file. Modifying this file will          *
# *   interfere with the grading system, lead to incorrect results, and       *
# *   will be flagged as cheating.                                            *
# *                                                                           *
# *   Focus on writing your own code to meet the requirements outlined in the *
# *   tests.                                                                  *
# *                                                                           *
# *****************************************************************************

import requests
import json
import sys
sys.path.append('..')
from central_setup.central_setup import ( execute_logic, run_single_test, run_program )

program_name = 'medicationTracker.py' # The name of the file the student is assigned to write
test_file = 'tests/test_program.py' # The name of the test file to check the student code

def run_test(test_name, test_description, error_message):
    run_single_test(test_name, test_description, error_message, pre_test_setup)

# Logic functions for each test
def logic_view_medications():
    return run_program(["2", "Aspirin", "1", "4"], program_name)

def logic_add_medication():
    return run_program(["2", "Ibuprofen", "1", "4"], program_name)

def logic_update_medication():
    return run_program(["2", "Lipitor", "20", "3", "Lipitor", "40", "1", "4"], program_name)

def logic_remove_medication():
    return run_program(["2", "Tylenol", "2", "Ibuprofen", "3", "Tylenol", "1", "4"], program_name)

def logic_exit():
    return run_program(["4"], program_name)

def pre_test_setup(test_name=None):
    test_outputs = { }
    test_points_awarded = {}
    test_feedback = ""
    test_response_data = None

    # Get only the logic for the specified test, or all tests if no specific test is provided
    if test_name:
        if test_name == "check_view_medications":
            test_outputs["check_view_medications"] = logic_view_medications()
        elif test_name == "check_add_medication":
            test_outputs["check_add_medication"] = logic_add_medication()
        elif test_name == "check_update_medication":
            test_outputs["check_update_medication"] = logic_update_medication()
        elif test_name == "check_remove_medication":
            test_outputs["check_remove_medication"] = logic_remove_medication()
        elif test_name == "check_exit":
            test_outputs["check_exit"] = logic_exit()
    else:
        test_outputs = {
            "check_view_medications": logic_view_medications(),
            "check_add_medication": logic_add_medication(),
            "check_update_medication": logic_update_medication(),
            "check_remove_medication": logic_remove_medication(),
            "check_exit": logic_exit()
        }

    try:
        # Read the contents of the files
        with open(program_name, 'r') as f:
            student_code = f.read()
        with open(test_file, 'r') as f:
            pytest_code = f.read()
        with open('.github/classroom/autograding.json', 'r') as f:
            autograding_config = json.load(f)

        # Pass the logic to the central_setup module
        test_outputs, test_points_awarded, test_feedback, test_response_data = execute_logic(
            test_name, test_outputs, student_code, pytest_code, autograding_config
        )

    except (requests.exceptions.RequestException, json.JSONDecodeError) as e:
        print(f"API call failed: {e}")
        print("Proceeding without API response. Run the test again with a working API to receive more user-friendly feedback.")

    return test_outputs, test_points_awarded, test_feedback, test_response_data
