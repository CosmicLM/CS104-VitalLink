from helper_methods import run_tracker
from common_setup import run_test

def view_medications_test():
    # Add a medication, then view
    output = run_tracker(["2", "Aspirin", "1", "4"])
    assert output, "\U0000274C medicationTracker.py did not print any output. Hint: make sure to use print()!"
    assert "Aspirin" in output, (
        "\U0000274C Option 1 (View medications) did not show the added medication.\n"
        "\U0001F4A1 Hint: After adding a medication, viewing should list it."
    )
    assert "Your medications" in output, (
        "\U0000274C Option 1 (View medications) did not print the correct header.\n"
        "\U0001F4A1 Hint: Make sure to print 'Your medications (in alphabetical order):' when viewing."
    )

def test_view_medications():
    run_test("check_view_medications", "Option 1: View Medications - show all medications in the dictionary", "\U0000274C Option 1 (View medications) did not print the correct header.")