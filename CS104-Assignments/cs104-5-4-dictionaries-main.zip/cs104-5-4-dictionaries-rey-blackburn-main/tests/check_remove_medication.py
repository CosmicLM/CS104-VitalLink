from helper_methods import run_tracker
from common_setup import run_test

def remove_medication_test():
    # Add, then remove
    output = run_tracker(["2", "Tylenol", "2", "Ibuprofen", "3", "Tylenol", "1", "4"])
    assert output, "\U0000274C medicationTracker.py did not print any output. Hint: make sure to use print()!"
    assert "'Tylenol' has been added" in output, (
        "\U0000274C Option 2 (Add medication) did not confirm addition.\n"
        "\U0001F4A1 Hint: Print \"'<ADDED_MEDICATION>' has been added\" after the user adds a medication."
    )
    assert "'Tylenol' has been removed" in output, (
        "\U0000274C Option 3 (Remove medication) did not confirm removal.\n"
        "\U0001F4A1 Hint: Print \"'<REMOVED_MEDICATION>' has been removed\" after the user removes a medication."
    )
    # After removal, Tylenol should not be listed
    lines = output.splitlines()
    meds_section = False
    for line in lines:
        if "Your medications" in line:
            meds_section = True
        elif meds_section and line.strip() == "":
            meds_section = False
        elif meds_section:
            assert "Tylenol" not in line, (
                "\U0000274C Option 3 (Remove medication) did not actually remove the medication from the list.\n"
                "\U0001F4A1 Hint: After removal, viewing should not list the medication."
            )

def test_remove_medication():
    run_test("check_remove_medication", "Option 4: Remove Medication - delete a medication from the dictionary", "\U0000274C Option 4 (Remove medication) did not confirm removal/actually remove the medication.")