# CS 104 - Assignment 5.3 - Lists

In this assignment, you will learn how to use dictionaries to keep track of and manage multiple pieces of information.


## Instructions

### Clone (download) your repo from GitHub

- Copy the SSH link from GitHub
- Open a new terminal
- `git clone <REPO_LINK>`

### Complete the assignment

- Open the repo in VS Code
- Open **medicationTracker.py**
- Follow the instructions in the TODO comment
- Run your code: `py medicationTracker.py`

### Example Run
```
-----------------------------------------
Welcome to VitalLink's medication tracker
-----------------------------------------

What would you like to do?
--------------------------
1. View medications
2. Add a medication
3. Update a medication dosage
4. Remove a medication
5. Exit
--------------------------
Enter your choice (1-5): <INVALID_CHOICE>
Invalid choice. Please enter a number between 1 and 5.
Enter your choice (1-5): 2
Enter medication name to add: <MEDICATION_1>
Enter dosage amount (mg): <DOSAGE>  
'<MEDICATION_1>' has been added.

What would you like to do?
--------------------------
1. View medications
2. Add a medication
3. Update a medication dosage
4. Remove a medication
5. Exit
--------------------------
Enter your choice (1-5): 2
Enter medication name to add: <MEDICATION_2>
Enter dosage amount (mg): <DOSAGE>
'<MEDICATION_2>' has been added.

What would you like to do?
--------------------------
1. View medications
2. Add a medication
3. Update a medication dosage
4. Remove a medication
5. Exit
--------------------------
Enter your choice (1-5): 1
Your medications (in alphabetical order):
<MEDICATION_1>: <DOSAGE>mg
<MEDICATION_2>: <DOSAGE>mg

What would you like to do?
--------------------------
1. View medications
2. Add a medication
3. Update a medication dosage
4. Remove a medication
5. Exit
--------------------------
Enter your choice (1-5): 3
Enter medication name to update: <MEDICATION_1>
Enter new dosage amount (mg): <UPDATED_DOSAGE>
'<MEDICATION_1>' has been updated.

What would you like to do?
--------------------------
1. View medications
2. Add a medication
3. Update a medication dosage
4. Remove a medication
5. Exit
--------------------------
Enter your choice (1-5): 4
Enter medication name to remove: <MEDICATION_2>
'<MEDICATION_2>' has been removed.

What would you like to do?
--------------------------
1. View medications
2. Add a medication
3. Update a medication dosage
4. Remove a medication
5. Exit
--------------------------
Enter your choice (1-5): 1
Your medications (in alphabetical order):
<MEDICATION_1>: <UPDATED_DOSAGE>mg

What would you like to do?
--------------------------
1. View medications
2. Add a medication
3. Update a medication dosage
4. Remove a medication
5. Exit
--------------------------
Enter your choice (1-5): 5
Thank you for using VitalLink's medication tracker!
```

### Test your assignment

- Install the required libraries: `pip install -r requirements.txt`
- Run the tests to check your work: `pytest`
- If you get a red **failed** message, read the error messages and fix your assignment accordingly
- If you get a green **passed** message, you have completed the assignment correctly

### Submit your assignment

Push your changes to GitHub:
- `git add .`
- `git commit -m "changed the README.md file"`
- `git push`